import React, { useState } from "react";
export default function Home() {
    return (
      <div className=' text-white text-lg'>
        <div className='flex items-center mb-6'>
        <div className='font-bold text-2xl'>HOME </div>
        <i className='bx bx-chevron-down text-4xl mt-1 text-white'></i>
      </div>
      </div>
    )
}