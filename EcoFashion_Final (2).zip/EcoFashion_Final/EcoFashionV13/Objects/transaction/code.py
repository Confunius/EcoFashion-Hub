class Code:
    def __init__(self, code, discount, end_date):
        self.code = code
        self.discount = discount
        self.end_date = end_date